
import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 md:py-32 bg-slate-900">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
          Wir formen <span className="text-orange-500">Stimmen</span> zu <span className="text-cyan-400">Erfolg.</span>
        </h2>
        <div className="max-w-3xl mx-auto border-t-2 border-cyan-400/20 pt-8 mt-8">
            <p className="text-lg md:text-xl text-gray-300 leading-relaxed">
            Teleformers ist eine Plattform zur Ausbildung und Vermittlung von Telefon-Talenten.
            Wir machen aus Menschen professionelle Kommunikator:innen. Ob Kundenservice, Verkauf oder Recherche – mit klarer Sprache, Empathie und Technikverständnis.
            Unsere Agent:innen arbeiten remote und sind sofort einsatzbereit – perfekt für moderne Unternehmen, die auf professionelle Kommunikation setzen.
            </p>
        </div>
      </div>
    </section>
  );
};

export default About;
