
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section id="hero" className="relative h-screen flex items-center justify-center text-center bg-slate-900 overflow-hidden">
      {/* Futuristic background effect */}
      <div className="absolute inset-0 bg-slate-900 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(14,165,233,0.3),rgba(255,255,255,0))]"></div>
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:2rem_2rem]"></div>
      
      <div className="relative z-10 p-6 flex flex-col items-center">
        {/* The user should place their logo.png in the public folder */}
        <img src="/logo.png" alt="TeleFormers Logo" className="w-48 md:w-64 h-auto mb-4 drop-shadow-2xl" />
        <h1 className="text-4xl md:text-6xl font-bold tracking-tighter text-white uppercase" style={{ textShadow: '0 2px 10px rgba(0,0,0,0.5)' }}>
          TeleFormers
        </h1>
        <p className="mt-2 text-xl md:text-2xl font-medium text-orange-500 tracking-wide">
          Formation für Kommunikation
        </p>
        
        <div className="mt-10 flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6">
          <a href="#talents" className="px-8 py-4 bg-orange-600 text-white font-bold rounded-lg shadow-lg hover:bg-orange-500 transform hover:scale-105 transition-all duration-300 ease-in-out focus:outline-none focus:ring-4 focus:ring-orange-400 focus:ring-opacity-50 animate-pulse-glow">
            Jetzt Talent werden
          </a>
          <a href="#companies" className="px-8 py-4 border-2 border-cyan-400 text-cyan-400 font-bold rounded-lg shadow-lg hover:bg-cyan-400 hover:text-slate-900 transform hover:scale-105 transition-all duration-300 ease-in-out focus:outline-none focus:ring-4 focus:ring-cyan-300 focus:ring-opacity-50">
            Für Unternehmen
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;
