
import React, { useState } from 'react';
import { UserIcon, EmailIcon, BriefcaseIcon, StarIcon } from './Icons';

const ContactForm: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
    userType: 'talent',
  });
  const [status, setStatus] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
        setStatus('Bitte füllen Sie alle Felder aus.');
        return;
    }
    console.log('Form submitted:', formData);
    setStatus('Vielen Dank! Ihre Nachricht wurde gesendet.');
    setFormData({ name: '', email: '', message: '', userType: 'talent' });
    setTimeout(() => setStatus(''), 5000);
  };

  return (
    <section id="contact" className="py-20 md:py-32 bg-slate-900/50 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(249,115,22,0.1),transparent_70%)]"></div>
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-5xl font-bold text-white">Kontaktieren Sie uns</h2>
          <p className="mt-4 text-lg text-gray-400">Wir freuen uns auf Ihre Nachricht.</p>
        </div>
        
        <div className="max-w-2xl mx-auto bg-slate-800/50 p-8 rounded-2xl border border-slate-700 shadow-2xl backdrop-blur-sm">
          <form onSubmit={handleSubmit} className="space-y-6">
            
            <div className="grid sm:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="userType" className="block text-sm font-medium text-gray-300 mb-2">Ich bin...</label>
                    <div className="relative">
                        <select
                            id="userType"
                            name="userType"
                            value={formData.userType}
                            onChange={handleChange}
                            className="w-full pl-10 pr-4 py-3 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition"
                        >
                            <option value="talent">Ein Talent</option>
                            <option value="company">Ein Unternehmen</option>
                        </select>
                         <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            {formData.userType === 'talent' ? <StarIcon className="h-5 w-5 text-gray-400" /> : <BriefcaseIcon className="h-5 w-5 text-gray-400" />}
                        </div>
                    </div>
                </div>
            </div>

            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">Name</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <UserIcon className="h-5 w-5 text-gray-400" />
                </div>
                <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} className="w-full pl-10 pr-4 py-3 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition" placeholder="Ihr Name" />
              </div>
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">E-Mail</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <EmailIcon className="h-5 w-5 text-gray-400" />
                </div>
                <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} className="w-full pl-10 pr-4 py-3 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition" placeholder="ihre@email.de" />
              </div>
            </div>

            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">Nachricht</label>
              <textarea name="message" id="message" rows={5} value={formData.message} onChange={handleChange} className="w-full px-4 py-3 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition" placeholder="Ihre Anfrage..."></textarea>
            </div>

            <div>
              <button type="submit" className="w-full px-8 py-4 bg-orange-600 text-white font-bold rounded-lg shadow-lg hover:bg-orange-500 transform hover:scale-105 transition-all duration-300 ease-in-out focus:outline-none focus:ring-4 focus:ring-orange-400 focus:ring-opacity-50">
                Nachricht senden
              </button>
            </div>
          </form>
          {status && <p className="mt-4 text-center text-orange-400">{status}</p>}
        </div>
      </div>
    </section>
  );
};

export default ContactForm;
