
import React from 'react';

const BenefitItem: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="relative pl-8">
        <div className="absolute left-0 top-1 h-4 w-4 bg-orange-500 transform rotate-45"></div>
        <h3 className="text-xl font-bold text-white mb-2">{title}</h3>
        <p className="text-gray-400">{children}</p>
    </div>
);

const ForCompanies: React.FC = () => {
  return (
    <section id="companies" className="py-20 md:py-32 bg-slate-900">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div className="text-center md:text-left">
            <h2 className="text-3xl md:text-5xl font-bold text-white">Für <span className="text-orange-500">Unternehmen</span></h2>
            <p className="mt-4 text-lg md:text-xl text-gray-400 max-w-xl mx-auto md:mx-0">
              Steigern Sie Ihre Effizienz mit professionell ausgebildeten Kommunikationstalenten – remote, flexibel und sofort einsatzbereit.
            </p>
          </div>
          
          <div className="space-y-8">
              <BenefitItem title="Sofort einsatzbereite Kräfte">
                  Unsere Talente durchlaufen intensive Schulungen und sind vom ersten Tag an produktiv und professionell.
              </BenefitItem>
              <BenefitItem title="Remote & Skalierbar">
                  Greifen Sie auf einen deutschlandweiten Pool an Talenten zu. Skalieren Sie Ihr Team flexibel nach Bedarf, ohne Büroinfrastruktur.
              </BenefitItem>
              <BenefitItem title="Professionell geschult">
                  Wir garantieren höchste Qualitätsstandards in der Kommunikation, egal ob im Service, Verkauf oder Inbound.
              </BenefitItem>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ForCompanies;
