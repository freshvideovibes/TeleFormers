
import React from 'react';
import { LearnIcon, CommunicateIcon, EarnIcon } from './Icons';

const TalentCard: React.FC<{ icon: React.ReactNode; title: string; children: React.ReactNode }> = ({ icon, title, children }) => (
  <div className="bg-slate-800/50 p-8 rounded-xl border border-slate-700 hover:border-cyan-400 transition-all duration-300 transform hover:-translate-y-2 hover:shadow-2xl hover:shadow-cyan-500/10">
    <div className="flex justify-center items-center mb-6 h-16 w-16 rounded-full bg-slate-700 text-cyan-400 mx-auto">
      {icon}
    </div>
    <h3 className="text-2xl font-bold text-white text-center mb-4">{title}</h3>
    <p className="text-gray-400 text-center leading-relaxed">{children}</p>
  </div>
);

const ForTalents: React.FC = () => {
  return (
    <section id="talents" className="py-20 md:py-32 bg-slate-900/50" style={{ backgroundImage: "radial-gradient(rgba(14, 165, 233, 0.05) 1px, transparent 1px)", backgroundSize: "2rem 2rem"}}>
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white">Für Talente</h2>
          <p className="mt-4 text-lg md:text-xl text-gray-400 max-w-2xl mx-auto">Was dich erwartet: Top-Schulungen, flexible Arbeit im Homeoffice und eine sichere Vermittlung.</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          <TalentCard icon={<LearnIcon className="w-8 h-8" />} title="Lernen">
            Werde zum Kommunikationsprofi. Wir schulen dich in Rhetorik, Produktwissen und den neuesten digitalen Tools.
          </TalentCard>
          <TalentCard icon={<CommunicateIcon className="w-8 h-8" />} title="Kommunizieren">
            Arbeite flexibel von zu Hause aus. Alles was du brauchst ist eine stabile Internetverbindung und deine Stimme.
          </TalentCard>
          <TalentCard icon={<EarnIcon className="w-8 h-8" />} title="Verdienen">
            Wir vermitteln dich an Top-Unternehmen. Profitiere von fairer Bezahlung und sicheren Job-Perspektiven.
          </TalentCard>
        </div>
      </div>
    </section>
  );
};

export default ForTalents;
